# Development

## Setup

```bash
git clone https://github.com/freva-org/reflow
cd reflow
pip install -e ".[dev]"
```

## Running tests

```bash
pytest -v tests/
tox -e test
```

## Linting and type checking

```bash
ruff check src/
mypy src/reflow
tox -e lint
tox -e types
```

## Building docs

```bash
pip install -e ".[docs]"
mkdocs serve
```

## What to keep stable

At this stage, the most important surfaces to keep stable are:

- public decorator API (`@wf.job()`, `Param`, `Result`, `RunDir`)
- `Run` control surface (`.status()`, `.cancel()`, `.retry()`)
- `Executor` protocol (`.submit()`, `.cancel()`, `.job_state()`, `.dependency_options()`)
- manifest storage behaviour and cache semantics
- CLI subcommand names and flag conventions

## Code organisation

```text
src/reflow/
├── __init__.py          — public re-exports
├── _types.py            — RunState, TaskState enums
├── cache.py             — Merkle-DAG identity hashing
├── cli.py               — argparse CLI generation
├── config.py            — user config + rosetta stone
├── executors/           — scheduler backends
│   ├── __init__.py      — Executor ABC, JobResources
│   ├── helpers.py       — default_executor, resolve_executor
│   ├── slurm.py
│   ├── pbs.py
│   ├── lsf.py
│   ├── sge.py
│   ├── flux.py
│   └── local.py
├── flow.py              — Flow, JobConfig, TaskSpec
├── manifest.py          — typed JSON codec
├── params.py            — Param, Result, RunDir, wire modes
├── results.py           — file-based worker results
├── run.py               — Run handle
├── signals.py           — graceful shutdown
├── stores/              — persistence
│   ├── __init__.py      — Store ABC
│   ├── records.py       — typed dataclass records
│   └── sqlite.py        — SqliteStore
└── workflow/            — execution engine
    ├── __init__.py      — re-exports
    ├── _core.py         — Workflow class
    ├── _dispatch.py     — DispatchMixin
    ├── _worker.py       — WorkerMixin
    └── _helpers.py      — make_run_id, build_kwargs, etc.
```

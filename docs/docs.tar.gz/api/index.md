# API reference

Auto-generated from docstrings.

- [Core workflow objects](core.md) — `Flow`, `Workflow`, `Run`
- [Parameters and results](params.md) — `Param`, `Result`, `RunDir`
- [Executors](executors.md) — `Executor`, `SlurmExecutor`, `PBSExecutor`, `LSFExecutor`, `SGEExecutor`, `FluxExecutor`, `LocalExecutor`
- [Stores](stores.md) — `SqliteStore`
- [Other](other.md) — `TaskInterrupted`, `Config`, `ManifestCodec`
